package com.example.torchwebsite.controller;

import cn.hutool.json.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.api.pojo.Volunteer;
import com.example.api.pojo.vo.Volunteer.VolunteerInfo;
import com.example.torchwebsite.service.VolunteerService;
import com.example.torchwebsite.utils.ImgRegulation;
import com.example.torchwebsite.utils.R;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/admin/volunteer")
public class VolunteerController {
    @Resource
    private VolunteerService volunteerService;
    //    查询志愿者风采
    @GetMapping
    public R<?> selectVolunteers(HttpServletRequest request, HttpServletResponse response,
                                 @RequestParam(defaultValue = "1") Integer pageNum,
                                 @RequestParam(defaultValue = "10") Integer pageSize){

        QueryWrapper<Volunteer> wrapper = new QueryWrapper<>();
        BaseMapper<Volunteer> baseMapper = volunteerService.getBaseMapper();
        Page<Volunteer> volunteers = baseMapper.selectPage(new Page<>(pageNum, pageSize),wrapper);
        List<Volunteer> records = volunteers.getRecords();
        long total = volunteers.getTotal();
        JSONObject jsonObject = new JSONObject();
        jsonObject.set("records",records);
        jsonObject.set("total",total);

        return R.ok().detail(jsonObject);
    }
    @GetMapping("/a")
    public R<?> selectVolunteers2(HttpServletRequest request, HttpServletResponse response,
                                 @RequestParam(defaultValue = "1") Integer pageNum,
                                 @RequestParam(defaultValue = "10") Integer pageSize){

        QueryWrapper<Volunteer> wrapper = new QueryWrapper<>();
        Page<Volunteer> volunteers = volunteerService.getBaseMapper().selectPage(new Page<>(pageNum, pageSize),wrapper);

        long total = volunteers.getTotal();
        JSONObject jsonObject = new JSONObject();
        jsonObject.set("total",total);

        Iterator<Volunteer> iterator = volunteerService.getBaseMapper().selectList(wrapper).iterator();
        while (iterator.hasNext()) {
            byte[] b = null;
            b = iterator.next().getImage();
            InputStream is = new ByteArrayInputStream(b);
            try {
                //通过文件流将图片传给前端
                ServletOutputStream out = response.getOutputStream();
                int len = 0;
                byte[] buf = new byte[1024];
                while ((len = is.read(buf, 0, 1024)) != -1) {
                    out.write(buf, 0, len);
                }
                out.flush();
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        List<Volunteer> records = volunteers.getRecords();
        jsonObject.set("records",records);
        return R.ok().detail(jsonObject);
    }

    //删除志愿者风采
    @DeleteMapping("/{id}")
    public R<?> deleteVolunteer(@PathVariable Integer id,HttpServletRequest request, HttpServletResponse response){

        int res = volunteerService.getBaseMapper().deleteById(id);
        if (res == 0){
            return R.error().message("数据库删除失败");
        }
        return R.ok().message("");
    }

    //添加志愿者风采信息
    @PostMapping("/upload")
    public R<?> insertVolunteer(MultipartFile file, HttpServletRequest request, HttpServletResponse response){

        Volunteer newVolunteer = new Volunteer();
        try {
            newVolunteer.setImage(file.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
//        newVolunteer.setName(volunteerInfo.getName());
//        newVolunteer.setContent(volunteerInfo.getContent());
//        newVolunteer.setUrl(volunteerInfo.getUrl());
//        newVolunteer.setImage(volunteerInfo.getImage());
//        newVolunteer.setPlace(volunteerInfo.getPlace());
//        newVolunteer.setDate(volunteerInfo.getDate());
//        newVolunteer.setName(volunteerInfo.getName());



        int res = volunteerService.getBaseMapper().insert(newVolunteer);
        if (res == 0){

            return R.error().message("数据库添加失败");
        }
        return R.ok().message("");
    }
//
//    @GetMapping("/{id}")
//    public R<?> getVolunteer(@PathVariable Integer id){
//        Volunteer volunteer = volunteerService.getBaseMapper().selectById(id);
//        return R.ok().detail(volunteer);
//    }
}

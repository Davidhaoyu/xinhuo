package com.example.torchwebsite.utils.inter;

/**
 * 用于存放有关缓存的时间、名字等，规范化
 */
public interface CacheCode {
    long TOKEN_TIME = (long) (3600+Math.random()*10);
    //long TOKEN_TIME = (long) (3600+Math.random()*10);//用户登录时产生的token的有效时间,s

    //String CACHE_ACTIVITY_INFO = "activityInfo:";//封装的志愿活动信息缓存前缀
}

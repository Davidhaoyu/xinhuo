package com.example.torchwebsite.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.api.pojo.Volunteer;

public interface VolunteerService extends IService<Volunteer> {
}

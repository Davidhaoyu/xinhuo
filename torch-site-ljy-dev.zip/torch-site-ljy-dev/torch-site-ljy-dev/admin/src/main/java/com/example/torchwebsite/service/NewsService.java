package com.example.torchwebsite.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.api.pojo.News;

public interface NewsService extends IService<News> {
}

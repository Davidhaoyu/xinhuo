package com.example.torchwebsite.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.api.pojo.Member;

public interface MemberService extends IService<Member> {
}

package com.example.torchwebsite.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.api.pojo.NewsImages;

public interface NewsImagesService extends IService<NewsImages> {

}

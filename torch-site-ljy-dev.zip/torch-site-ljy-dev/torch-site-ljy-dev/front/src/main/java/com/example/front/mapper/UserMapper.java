package com.example.front.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.api.pojo.User;

public interface UserMapper extends BaseMapper<User> {

}

package com.example.api.pojo;

import lombok.Data;

@Data
public class NewsImages {
    private Integer id;
    private Integer news_id;
    private String image;
}

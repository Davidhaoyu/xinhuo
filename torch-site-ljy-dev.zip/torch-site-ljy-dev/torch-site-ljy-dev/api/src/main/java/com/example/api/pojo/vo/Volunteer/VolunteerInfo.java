package com.example.api.pojo.vo.Volunteer;

import lombok.Data;

@Data
public class VolunteerInfo {
    private byte[] image;
}

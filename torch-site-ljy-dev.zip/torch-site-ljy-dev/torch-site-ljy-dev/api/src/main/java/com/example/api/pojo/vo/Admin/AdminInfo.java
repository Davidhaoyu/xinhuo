package com.example.api.pojo.vo.Admin;

import lombok.Data;

@Data
public class AdminInfo {
    private String name;
    private String password;
}

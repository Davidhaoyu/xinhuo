package com.example.api.pojo.vo.News;

import lombok.Data;

@Data
public class NewsInfo {
}

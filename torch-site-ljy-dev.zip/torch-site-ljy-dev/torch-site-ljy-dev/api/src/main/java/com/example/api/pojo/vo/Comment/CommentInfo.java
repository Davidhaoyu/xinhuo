package com.example.api.pojo.vo.Comment;

import lombok.Data;

@Data
public class CommentInfo {

}

package com.example.api.pojo.vo.Member;

import lombok.Data;

@Data
public class MemberInfo {
    private Integer id;
    private String name;
    private String image;
    private String introduce;
    private String place;
}
